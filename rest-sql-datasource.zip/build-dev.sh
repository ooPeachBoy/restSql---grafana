yarn run build
cp -r ../rest-sql-datasource ../src/github.com/grafana/grafana/data/plugins/